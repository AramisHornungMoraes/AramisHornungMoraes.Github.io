//Copyright (c) 2015 Aramis Hornung Moraes
//
//AParser's source codes, documentation and binaries contained within the 
//distributed archive are copyright � Aramis Hornung Moraes 2015.
//
//The contents of the AParser distribution archive may NOT be redistributed, 
//reproduced, modified, transmitted, broadcast, published or adapted in any 
//way, shape or form, without the prior written consent of the owner, 
//Aramis Hornung Moraes.
//
//THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR
//CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
//EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
//PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
//PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

int aparser_file_size(char* file_name); // Return a pointer for the file data. Dont forget to free the memory.

char *aparser_load_file_to_cstring(char* file_name); // Return a pointer for the file data. Dont forget to free the memory.

// compare the current string "program[pc]" is same string as cmp_labels[type_id])
int aparser_is(char *program, int *pc, int file_len, int type_id, char **cmp_labels);

/* retorna um vetor com TODOS os parametros a  presebtes ebtre o primeiro "(" e terminando com ")" NAO ESQUECA DE CHAMAR aparser_DropParameters apos usar este vetor!!!! */
char **aparser_GetParameters(char *program, int *pc, int *param_c);

void aparser_DropParameters(char **parameters, int param_c);

// returns the correspondent type to the labels index vector, the arguments are stored in the last parameter "char ***ret_args"
int parse_file_for_param(char *file_name, int *fp, char ** labels, int n_labels, char ***ret_args, int *n_args);