int aparser_file_size(char* file_name); // Return a pointer for the file data. Dont forget to free the memory.

char *aparser_load_file_to_cstring(char* file_name); // Return a pointer for the file data. Dont forget to free the memory.

// compare the current string "program[pc]" is same string as cmp_labels[type_id])
int aparser_is(char *program, int *pc, int file_len, int type_id, char **cmp_labels);

/* retorna um vetor com TODOS os parametros a  presebtes ebtre o primeiro "(" e terminando com ")" NAO ESQUECA DE CHAMAR aparser_DropParameters apos usar este vetor!!!! */
char **aparser_GetParameters(char *program, int *pc, int *param_c);

void aparser_DropParameters(char **parameters, int param_c);

// returns the correspondent type to the labels index vector, the arguments are stored in the last parameter "char ***ret_args"
int parse_file_for_param(char *file_name, int *fp, char ** labels, int n_labels, char ***ret_args, int *n_args);