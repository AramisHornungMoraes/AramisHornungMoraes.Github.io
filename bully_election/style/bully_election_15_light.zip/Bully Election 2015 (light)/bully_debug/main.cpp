// TinyEnet - Minimalistic Networking engine
// Wrapper for ENet Networking Engine
// and
// AParser - C Like parser
// are
// Copyright (c) 2015 Aramis Hornung Moraes, THE USE OF THIS
// SOFTWARE/PROGRAM/CODE IS SUBJECTED TO LICENSE TERMS
// --------------------------------------
//
//
//
// THIS PROGRAM WAS DEVELOPED FOR A COLLEGE WORK
// Group: Alexande M.; Aramis H.; Arthur A.
// --------------------------------------
//
//
//
// Example of a bully election network.
// more info: https://en.wikipedia.org/wiki/Bully_algorithm
// Our ID number shall be the last IP number
// The network group is static, we will pre-write the IP
// addresses in a file.

#include "tnet/TNet.h"
#include "aparser/AParser.h"
#include <string.h>
#include <time.h>       /* time */

#define n_tries_resend 10 // number of trys to attempt to send a message in order to asure that the destination received it.
#define N_MAX_PROCS 20 // number of process in the network group

// Auxiliares para o parser
enum NType_ID // Node type id
{
	TProcess =		0,
	TDev =			1,
	NT_None =		9999
}NType_ID;

// Comandos escritos no codigo, � interessante estarem na mesma ordem na enumeracao acima... vlw flw
char *cmp_labels[] = {"process", "development"};

#define max_nodes_type_count 2 // numer of different nodes type above

typedef struct tn_process {
	int id;		// The last ip number converted to integer.
	char ip[12];	// 
	char flag;	// c = coordinator, p = process;
	int port;	// c = coordinator, p = process;
}tn_process;

TNETServer *serv;
TNETClient *clinet;
int proc_counter	= 0, // counts the maximum possible number of procs while parsering the file.
	n_active_procs	= 0;   // Number of processes we know are active in the network group
int proc_index		= 0, // indentify what process we are in the list
	coord_index		= 0; // coordinator index in the list.
tn_process procs[N_MAX_PROCS]; // the processes vector*/


// More information on readme
enum BULLY_BYTES_PROTOCOL
{
	BBP_CR=3,					// 01. Connection request
	BBP_CRR=4,					// 02. Connection request response
	BBP_CCA=5,					// 03. Check coor alive
	BBP_CCAR=6,					// 04. Check coor alive response
	BBP_NEW_PROCESS_JOINED=7,	// 04. Check coor alive response
	BBP_ELECTION=8,				// 04. Check coor alive response
	BBP_OK=9,					// 04. Check coor alive response
	BBP_COORDINATOR=10			// 04. Check coor alive response
};

//adiciona o parametro a lista estatica de processos dsitribuidos
void tn_add_proc(char **arg);
int fetch_proc_index_from_id(int id);
// Find any adress that matchs in the file with our information
int configure_machine(char *file);
void BullyStart();
// send the I'm alive message to destination
void BullyRespondImAlive(char *data);
int BullyCheckCoordAlive(int time_wait, int n_tryes = 4);
int BullyElection(int n_tryes = 3);
int ParseData(char *data, int n_tryes = 5);
void BullyUpdate(int uSecs, int stak_parse_only = 0);
void ApplyCoordinator(char *data); // check if coordiantor is valid and consider it the serving process.
void flushStack();

// do nothing but stack some messages
void BullyListen(int us_time= 2000, int times=5)
{
	srand(time(NULL));
	int time_ = rand() % abs(us_time) + (us_time/2);
	while(times)
	{
		printf("STANDBY__%d time, waiting %d\n", times, time_);
		if (serv->update(time_) == TEE_MESSAGE)
			ParseData(serv->getMessage()); // listen to the network
	--times;
	}
}

// Little exampleasdasd
int main(int argc, char **argv)
{
	srand(time(NULL));
	if(configure_machine("network.properties"))
	{
		BullyStart(); // fetch the coordinator in the network

		while(1)
		{
			int time = rand() % (proc_counter*250) + ((procs[proc_index].id)*250);

			if(coord_index != proc_index) // Im not cordinator, ping the coordinator to check if he is alive. 
			{
				flushStack();
				BullyUpdate(time);
				if(!BullyCheckCoordAlive(time) ) // rand from 500 to id*1000us and try to talk to server 100 times
				{
					printf("Corrdinator not responding: Launching election....\n");
					BullyElection(8);
				}
				BullyListen(time);
				//else
					//flushStack();
					//Sleep(rand() % abs(2000*(procs[proc_index].id)) + 1000);
			}
			else
				BullyUpdate(0); // rand 0us-500us
			
		}
	}
	fflush(stdin);getchar();
	return 0;
}

//adiciona o parametro a lista estatica de processos dsitribuidos
void tn_add_proc(char **arg)
{	
	strcpy(procs[proc_counter].ip, arg[0]);
	procs[proc_counter].id = atoi(arg[2]);
	procs[proc_counter].port = atoi(arg[1]);
	procs[proc_counter].flag = 0;
}
int fetch_proc_index_from_id(int id)
{
	printf("fetch index\n");
	int index = -1; // not the same thing as id... this is a INDEX not ID
	for(int j = 0; j < proc_counter; j++)
	{
		if(procs[j].id == id)
			index = j;
		printf("interation index\n");
	}
	return index;
}
// Find any adress that matchs in the file with our information
int configure_machine(char *file)
{	
	int	ponteiro = 0;
	char **param =0; int n_parms = 0;
	char my_ip[64];
	int my_port;
	int match_flag = 0; // did we found a matching address and port for in the process list
	int temp_prox_index = 0,
	    temp_match_flag = match_flag;

	startTNetEngine(); // Must have it.

	printf("Machine IP: "); fflush(stdin); scanf("%s", &my_ip); // CAUTION, DONT SURPASS THE NUMBER OF BYTER PERMITTED
	printf("Machine port: "); fflush(stdin); scanf("%d", &my_port);

	// Check if data gathered is in the config file.
	while(parse_file_for_param(file, &ponteiro, cmp_labels, 2, &param, &n_parms ) >= 0)
	{
		printf("%s %d %d", param[0], atoi(param[1]), atoi(param[2]));
		tn_add_proc(param);
		if(!strcmp(param[0], my_ip) && atoi(param[1]) == my_port)
		{
			printf(" - Matched!\n");
			temp_match_flag = match_flag = 1;
		}
		else
		{
			temp_prox_index++;
			printf("\n"); 
		}

		if(temp_match_flag) 
		{
			proc_index = temp_prox_index;
			temp_match_flag = 0; // if we have already defined a server, make sure we dont create another one for further process passes of this routine
		}
		proc_counter++; // count every process we find.
	}
	if(param) // DONT forget to drop the parameters
		aparser_DropParameters(param, n_parms);


	// now create the cliend and server if we have the necessary info
	if(match_flag) // failed to connect
	{
		clinet = new TNETClient();
		serv = new TNETServer(my_port);
		return 1;
	}
	else
	{
		printf("could not match any address for you");
		return 0;
	}
	
}
void BullyStart()
{
	printf("+++[=  BullyStart\n");

	char packet[3];
	int connected_f = 0;
	packet[0] = BBP_CR; // connection request flag
	packet[1] = (char)procs[proc_index].id;

	int i = 0; 
	while(i < proc_counter && !connected_f) // try to communicate with all the possible procs in the list
	{
		if(i != proc_index) // dont send the message to myself you GOOF
		{
			if(clinet->send(packet, procs[i].port, procs[i].ip, 2)) // try to send it first
			{
					printf("Server aceppeted my handshake.");
					if(serv->update(2000) == TEE_MESSAGE) // now that we are connected wait for a message
					{
						printf("Server responded to my request.");
						if(serv->getMessage()[0] == BBP_CRR) // a conection response message.
						{
							// gather the info received
							// find the coord index

							int coord_id = (int)serv->getMessage()[1];
							n_active_procs = (int)serv->getMessage()[2]; // n_active_procs is a global var

							//coord_index = fetch_proc_index_from_id(coord_id); // not the same thing as id... this is a INDEX not ID

							ApplyCoordinator(serv->getMessage());

							// present the information to user
							/*printf("[%s]> Connection aceepted\n"				\
								   "[%s]> Coordinator ID is: %d\n"				\
								   "[%s]> Number of active nodes: %d\n",		\
								   serv->getPacket().getSenderIP(),
								   serv->getPacket().getSenderIP(), coord_id,
								   serv->getPacket().getSenderIP(), n_active_procs
								   );*/
								   connected_f = 1; // indicate that we have connected
								   break; // break the while loop trying for connection
						}
					}
				
			}
		}
		i++;
	}

	if(connected_f)
	{
		printf("Connection stabilished with success\n");
		n_active_procs++;
		// avisar os outros
	}
	else // Im the first Im the coordinator
	{
		printf("No machine has responded to my connection request. Assuming coordination task.\n");
		coord_index = proc_index; // I'm the coordinator now
		// do sumfim
	}
}
// send the I'm alive message to destination
void BullyRespondImAlive(char *data)
{
	printf("+++[=  BullyRespondImAlive\n");

	if(data[0] == BBP_CCA) // Someone is checking if I (coordinator) m alive.
	{
		if(coord_index == proc_index) // m'I the coordinator?
		{
			int sender_id = (int)data[1];
			int sender_index = fetch_proc_index_from_id(sender_id); // address index to the procs vector of the sender of this request 

			if(sender_index >= 0) // we foudn someone in the vector of possible procs that match the origin of this connection request
			{
				char ccar[4];
				ccar[0] = BBP_CCAR; ccar[1] = procs[coord_index].id;
				printf(">> I'M ALIVE message request to: %s:%d\n", procs[sender_index].ip, (int)procs[sender_index].port); 
				//serv->update(500);
				clinet->send(ccar, (int)procs[sender_index].port, procs[sender_index].ip, 3);

			}
			else
				printf("Error, a stranger is trying to contact me.\n");
		}
		else
			printf("PROC-%d> Someone thinks I'm the coordinator, but ID: %d is the real coordinator\n", procs[proc_index].id, procs[coord_index].id);// print out that someone missrecognized me as the coordinator, we could tell this person the real coordinator but lets just print it to user and do nothing else...
	}
}
int BullyCheckCoordAlive(int time_wait, int n_tryes)
{
	printf("+++[=  BullyCheckCoordAlive\n");

	char crr[4];
	crr[0] = BBP_CCA; crr[1] = procs[proc_index].id;;
	printf("Checking if coordinator is alive (time givem %dx2)... ", time_wait);
	
	//clinet->send(crr, (int)procs[coord_index].port, procs[coord_index].ip, 3);
	while(n_tryes > 0)
	{
		printf("while bully check coord alive.\n");
		BullyUpdate(time_wait*2, 1); // only parse the stack, if any stacked packets -- ATEN��O, PODE ALTERAR O COORD INDEX, A IDEIA � EXATAMENTE ESSA.
		clinet->send(crr, (int)procs[coord_index].port, procs[coord_index].ip, 3);
		if(serv->update(time_wait*2) == TEE_MESSAGE)
		{
			if(serv->getMessage()[0] == BBP_CCAR) // coordiantor is alive! :D
			{
				int tcoord_id = (int)serv->getMessage()[1];
				printf("Coordinator (ID: %d) is alive.\n", tcoord_id);
				flushStack();
				printf("+++[=  BullyCheckCoordAlive ->>>> 1 (Coord ok)\n");
				return 1;
			}
			else
				serv->stackPushMessage(serv->getMessage());
			
		}
			
		n_tryes--;
		printf("attempt to check coordiantor alive remaining: %d\n", n_tryes);
		BullyListen(); // keep this fool waiting a little more, just because he is twitchy
		
	}
	//TODO do bully election here.
	printf("+++[=  BullyCheckCoordAlive ->>>> 0 (COORdiNATOR IS CONSIDERED DOWN)\n");
	return 0;
}
int BullyElection(int n_tryes)
{
	printf("+++[=  BullyElection\n");
	Stack temp_stack;
	int coord_elected = 0;

	for(int i = 0; i < proc_counter; ++i)
	{
		if(!coord_elected && procs[i].id > procs[proc_index].id)
		{
			// Buildup a simple election pack, containing the current process ID.
			char election_pack[3];
			election_pack[0] = BBP_ELECTION; // connection request flag
			election_pack[1] = (char)procs[proc_index].id;

			clinet->send(election_pack, procs[i].port, procs[i].ip, 2);

			// get all messages and stack them for processing
			while(serv->update(1000) == TEE_MESSAGE && !coord_elected && n_tryes > 0)
			{
				if(ParseData(serv->getMessage()) == BBP_ELECTION)
					break; // done a election before, GET THE HELL OUT OF HERE

				if(coord_index != proc_index)
				{
					if(BullyCheckCoordAlive(1000,n_tryes)); // the fool have responded me while i was on election, Great, he is alive thenm back to normal life i guess
					{
						printf("quiting from election\n");
						printf("+++[=  BullyElection ->>>> 0 (everything is ok, quiting)\n");
						return 0;
						printf("ERRO ERRO ERRO EROO EROO EROO\n");
					}
				}
				--n_tryes;
			}
		}
	}
	if(!coord_elected) // nobody responded my election, I'm the coordinator
	{
		printf("----------------I'm assuming I'm the coordinator now...\n");
		coord_index = proc_index; // experimenta comutar essa linha pra ver o CAOS que vira joveim ;)
		for(int i = 0; i < proc_counter; ++i)
		{
			// keep listening for some goofs asking about who is the freaking coordinator before they resolve to be a coordiantor aswell
			BullyUpdate(0);

			if(i != proc_index) // not my index
			{
				printf("IM COORD to proc %d: ",i+1);
				char coordinator_pack[3];
				coordinator_pack[0] = BBP_COORDINATOR; // connection request flag
				coordinator_pack[1] = (char)procs[proc_index].id;
				clinet->send(coordinator_pack, procs[i].port, procs[i].ip, 2);
			}
		}
	}
	printf("+++[=  BullyElection ->>>> 1 (IM COORDINATOR)\n");
	return 1;
}

void flushStack()
{
	printf("\n");
	int size = serv->stackSize() ;
	printf("$<STACK FLUSHED>______SIZE_(%d)_\n", size);
	while(size> 0)
	{
		free(serv->stackPopMessage());
		printf(".");
		size = serv->stackSize() ;
	}
	
}
int ParseData(char *data, int n_tryes)
{
	printf("+++[=  ParseData\n");
		if(data[0] == BBP_CR) // a conection request message.
		{
			int sender_id = (int)data[1];
			int sender_index = -1; // address index to the procs vector of the sender of this request 
			// find who send this request
			for(int i =0; i < proc_counter; i++)
				if(procs[i].id == sender_id)
					sender_index = i;


			if(sender_index >= 0) // we foudn someone in the vector of possible procs that match the origin of this connection request
			{
				char crr[4];
				crr[0] = BBP_CRR; crr[1] = procs[coord_index].id; crr[2] = n_active_procs;
				printf("Preparing to resend connection request to: %s:%d", procs[sender_index].ip, (int)procs[sender_index].port);
				clinet->send(crr, (int)procs[sender_index].port, procs[sender_index].ip, 3);
			}
			else
				printf("Error, a stranger is trying to contact me.\n");

			printf("+++[=  ParseData ->>>> BBP_CR\n");
			return BBP_CR;
		}
		if(data[0] == BBP_CCA) // Someone is checking if I (coordinator) m alive.
		{
			BullyRespondImAlive(data);
			printf("+++[=  ParseData ->>>> BBP_CCA\n");
			return BBP_CCA;
		}
		if(data[0] == BBP_COORDINATOR)
		{
			
			//coord_index=fetch_proc_index_from_id(serv->getMessage()[1]);
			ApplyCoordinator(data); // fixed
			//coord_elected = 1;
			//ApplyCoordinator(data);
			printf("+++[=  ParseData ->>>> BBP_COORDINATOR\n");
			return BBP_COORDINATOR;
		}
		if(data[0] == BBP_ELECTION)
		{
			char ok_r[2];
			ok_r[0] = BBP_OK;
			int sender_id = (int)data[1];
			int sender_index = fetch_proc_index_from_id(sender_id); // address index to the procs vector of the sender of this request 
			printf("OK to: %s:%d\n", procs[sender_index].ip, (int)procs[sender_index].port);
			//serv->update(500);
			clinet->send(ok_r, (int)procs[sender_index].port, procs[sender_index].ip, 3);
			flushStack();
			BullyElection();
			printf("+++[=  ParseData ->>>> BBP_ELECTION\n");
			return BBP_ELECTION;
		}
		if(data[0] == BBP_OK)
		{
			printf("I've been OK'd\n");
			
			if(!BullyCheckCoordAlive) // check if coordinator is alive, if it is, ignore this OK message, because we shouldn't enter a Election process
			{
				while(n_tryes > 0) // bloco confuso, tentar melhorar
				{
					if(serv->update(128*proc_counter) == TEE_MESSAGE)
					{
						char *temp_message;
						while(serv->stackSize() >0)
						{
							temp_message = (char*)serv->stackPopMessage();
							if(temp_message[0] == BBP_COORDINATOR)
							{
								ApplyCoordinator(serv->getMessage());
								printf("coordiantor from stack - delete this debug message\n");
								break;break;
							}
						}

						if((serv->getMessage()[0] != BBP_COORDINATOR))
						{
							if(serv->getMessage()[0] != BBP_OK && serv->getMessage()[0] != BBP_ELECTION && serv->getMessage()[0] != BBP_CR) // ignore it, we are already aware of the election
								serv->stackPushMessage(serv->getMessage());
						}
						if(serv->getMessage()[0] == BBP_COORDINATOR)
						{
							ApplyCoordinator(serv->getMessage());
							printf("+++[=  ParseData ->>>> BBP_COORDINATOR\n");
							return BBP_COORDINATOR;
						}		
					}
					--n_tryes;
					BullyListen(1000);
				}
				printf("+++[=  ParseData ->>>> BBP_OK\n");
				return BBP_OK;
			}
		}
		if(data[0] == BBP_CCAR)
		{
			printf("+++[=  ParseData ->>>> BBP_CCAR\n");
				return BBP_CCAR;
		}
		else
			printf("no match, value is : '%d'\n", serv->getMessage()[0]);
}
void ApplyCoordinator(char *data)
{
	printf("+++[=  ApplyCoordinator (flag: %d, coord: id )\n", data[0], data[1]);
	coord_index=fetch_proc_index_from_id(data[1]);
	printf("+++[= ~coordindex = %d\n", coord_index);
			if(procs[proc_index].id > procs[coord_index].id) // I should be the coordinator, U FOOLS....
			{
				printf("+++[= ~My id is bigger then the current coordinator, i should satart a election\n", coord_index);
				BullyElection(); // pos�vel recurs�o
				flushStack();
			}
			else
				printf("NEW COORD||| detected: <<%d>>\n",data[1]);
			flushStack();
}
void BullyUpdate(int uSecs, int stak_parse_only)
{
	printf("+++[=  BullyUpdate\n");

	// first process all the acumulated packs from previous blocking routines
	int size = serv->stackSize();
	if(stak_parse_only)
		printf("Stack size is : %d\n", size);
	while(serv->stackSize() > 0)
	{
		char*message = (char*)serv->stackPopMessage();
		printf("data: %d\n", message[0]);
		ParseData(message); // listen to the network
		free(message);
	}

	// now look for new packs
	if(!stak_parse_only && serv->update(uSecs) == TEE_MESSAGE)
		ParseData(serv->getMessage()); // listen to the network
}