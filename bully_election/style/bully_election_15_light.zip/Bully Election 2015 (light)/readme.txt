==========================================================================
The TNet SDK version 1.0
==========================================================================

  Welcome the TNet SDK.

  Content of this file:

  1. Directory structure overview
  2. How to start
  3. dependencies
  4. License
  5. Contact



==========================================================================
1. Directory structure overview
==========================================================================

  You will find some directories after decompressing the archive in which
  came the SDK. These are:
  
  \bin         Some compiled example applications, just start them to see
			   the TNet Engine in action.
  \doc         Documentation of the TNet Engine.
  \include     Header files to include when using the engine.
  \lib         Lib to link with your programs when using the engine.


==========================================================================
2. How to start
==========================================================================

  To see the engine in action in Windows, just go to the \bin
  directories, and start some applications. 
  
  To start developing own applications and games with the engine take 
  a look at the 01.HelloWorld example in the \source\examples directory.

  To compile: 
  Just go into the root directory and execute Cmake to build the project.
  This was tested only on Windows 7.
  	
==========================================================================
3. dependencies
==========================================================================

This is a simple wrapper for the ENet Networking engine. Therefore,
to use it you will need the ENet source code, that already is shped with
this SDK, be aware of it.

To know more about ENet visit:http://enet.bespin.org/
	
==========================================================================
4. License
==========================================================================

Copyright (c) 2015 Aramis Hornung Moraes

TNet's source codes, documentation and binaries contained within the 
distributed archive are copyright � Aramis Hornung Moraes 2015.

The contents of the TNet distribution archive may NOT be redistributed, 
reproduced, modified, transmitted, broadcast, published or adapted in any 
way, shape or form, without the prior written consent of the owner, 
Aramis Hornung Moraes.

The TNet.dll, TNet.so and libTNet.dylib, libTNet.a, TNet.lib files may be 
redistributed without the authors prior permission in non-commercial 
products, and must remain unmodified except for compressing the file.


THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

--------------------------------------------------------------------------
TNet may include ENet code
It's license is the following:

Copyright (c) 2002-2015 Lee Salzman

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files
(the "Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to permit
persons to whom the Software is furnished to do so, subject to the
following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

==========================================================================
5. Contact
==========================================================================

  If you have problems, questions or suggestions, please visit the 
  official homepage of the TNet Engine:
  
  http://aramishornungmoraes.github.io/
  
  If want to contact the author of the engine, please send an email to
  Aramis Hornung Moraes:
  
  Send a IM at https://plus.google.com/103791949210339737668
