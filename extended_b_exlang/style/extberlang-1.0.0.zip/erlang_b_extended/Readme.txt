

--------------------------- Como usar ---------------------------------
Erlang B estendido (SCANF).exe - � o mais port�til, mais provavel de funcionar em qualquer windows.

Erlang B estendido.exe - Vers�o janela (Mostrado na printscreen funcionamento.PNG)

erlang.exe - vers�o que funciona por par�metros (E, m, p)



Erlang.exe - Funciona por par�metro
Passar por par�metro o seguinte
	E - intensidade_chamadas
	m - numero_servidores
	p - probabilidade_retry

	Resultado
	B - probabilidade de bloqueio
	L - probabilidad de perda

A condi��o de parada do programa � um n�mero epsolon, abra o c�dgio digite (ctrl + f) e procure pela vari�vel de nome "epsolon"


