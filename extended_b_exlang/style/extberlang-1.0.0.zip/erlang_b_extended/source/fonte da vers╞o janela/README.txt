voc� deve usar CMAKE para criar o projeto

antes de tudo, descomprimir o .zip desta pasta